# Generate-OTP-API
API for generating OTP
